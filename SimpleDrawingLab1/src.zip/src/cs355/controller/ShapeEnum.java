package cs355.controller;

/**
 * Created by ben on 9/3/15.
 */
public enum ShapeEnum {
    LINE, SQUARE, RECTANGLE, CIRCLE, ELLIPSE, TRIANGLE
}
